package org.java.MemberCommend;

public interface MemberCommend {
	void excuteQueryCommend();
}