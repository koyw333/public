package org.java.exceptionEx;

import java.util.InputMismatchException;

public class ExceptionEx6 {
	public static void main(String[] args) {
		throws ArrayIndexOutOfBoundsException,
		InputMismatchException, ClassCastException;{
			
		}
	}
}
